# PrintDemon (CVE-2020-1048)

PrintDemon is a PoC for a series of issues in the Windows Print Spooler service, as well as potetial misuses of the functionality. Please read https://windows-internals.com/printdemon-cve-2020-1048/ for all of the information.
